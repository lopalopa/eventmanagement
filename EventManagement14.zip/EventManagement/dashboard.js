document.addEventListener('DOMContentLoaded', () => {
    const eventList = document.querySelector('#event-list');
    const attendeeList = document.querySelector('#attendee-list');

    const events = [
        { id: 1, name: "Tech Conference 2024", attendees: 50, ticketSales: 200 },
        { id: 2, name: "Music Festival", attendees: 150, ticketSales: 500 },
    ];

    const attendees = [
        { id: 1, name: "John Doe", email: "john@example.com" },
        { id: 2, name: "Jane Smith", email: "jane@example.com" },
    ];

    // Function to display events
    const displayEvents = () => {
        events.forEach(event => {
            const li = document.createElement('li');
            li.textContent = `${event.name} - Attendees: ${event.attendees}, Ticket Sales: $${event.ticketSales}`;
            eventList.appendChild(li);
        });
    };

    // Function to display attendees
    const displayAttendees = () => {
        attendees.forEach(attendee => {
            const li = document.createElement('li');
            li.textContent = `${attendee.name} - Email: ${attendee.email}`;
            attendeeList.appendChild(li);
        });
    };

    // Function to send notification
    const sendNotification = () => {
        const message = document.querySelector('#notification-message').value;
        if (message) {
            alert(`Notification sent: ${message}`);
            document.querySelector('#notification-message').value = ''; // Clear the message
        } else {
            alert('Please enter a message to send.');
        }
    };

    // Event listener for send notification button
    document.querySelector('#send-notification').addEventListener('click', sendNotification);

    // Initialize display
    displayEvents();
    displayAttendees();
});
